package com.company;

import java.lang.reflect.WildcardType;
import java.util.Comparator;

public class Employee {

    //, salary, position, department, email and age
    //mandatory->задължителни
    private String name;
    private double salary;
    private String position;
    private String department;
    //Optional
    private String email;
    private int age;

    //Mandatory
    public Employee(String name, double salary, String position, String department) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
        this.email = "n/a";
        this.age = -1;
    }
    //All 6
    public Employee(String name, double salary, String position, String department, String email, int age) {
        this(name, salary, position, department);
        this.email = email;
        this.age = age;
    }
    //Without age
    public Employee(String name, double salary, String position, String department, String email) {
        this(name, salary, position, department);
        this.email = email;
        this.age = -1;
    }
    //Without age
    public Employee(String name, double salary, String position, String department, int age) {
        this(name, salary, position, department);
        this.age = age;
        this.email = "n/a";
    }


    public double getSalary() {
        return salary;
    }


    public String getPosition() {
        return position;
    }


    public String getName() {
        return name;
    }


    public String getEmail() {
        return email;
    }


    public String getDepartment() {
        return department;
    }


    public int getAge() {
        return age;
    }


    @Override
    public String toString() {
        return String.format("%s %.2f %s %d", this.name, this.salary, this.email, this.age);
    }
}
