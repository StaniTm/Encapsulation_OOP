package com.company;

import java.util.*;


public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner scanner = new Scanner(System.in);
        int lines = Integer.parseInt(scanner.nextLine());
        Map<String, Department> departmentMap = new HashMap<>();


        while(lines-- > 0) {
            String[] input = scanner.nextLine().split("\\s+");
            String name = input[0];
            double salary = Double.parseDouble(input[1]);
            String position = input[2];
            String department = input[3];
            Employee employee;
            //check for length and see if length is 5 if its email or age
            if (input.length == 4) {
                employee = new Employee(name, salary, position, department);
            }else if (input.length == 6){
                employee = new Employee(name, salary, position, department, input[4], Integer.parseInt(input[5]));
            }else {
                //do we have a String or an Integer
                try {
                    int age = Integer.parseInt(input[4]);
                    employee = new Employee(name, salary, position, department, Integer.parseInt(input[4]));
                    //click on ParseInt check for what exceptions it throws!!
                }catch (NumberFormatException e){
                    String email = input[4];
                    employee = new Employee(name, salary, position, department, input[4]);
                }
            }
            //create new department if absent
            departmentMap.putIfAbsent(department, new Department(department));
            //returns list of employees abd adds one from map
            departmentMap.get(department).getEmployees().add(employee);
        }

        Department highestPaidDepartment = departmentMap
                .entrySet()
                .stream()
                .max(Comparator.comparing(entry -> entry.getValue().calculateAvgSalary()))
                .get()
                .getValue();

        System.out.println("Highest Average Salary: " + highestPaidDepartment.getName());
        highestPaidDepartment.getEmployees().stream().sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary())).forEach(System.out::println);


    }
}

